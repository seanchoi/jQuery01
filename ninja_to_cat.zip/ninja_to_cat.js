$("img").click( function () {
    
    $(this).attr("src", function () {
        return $(this).attr("data-alt-src");
    });
    
})