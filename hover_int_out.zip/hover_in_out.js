
$("img").hover( function () {
    $(this).attr("src", function() {
        return $(this).attr("alt");
    });
}, function () {
    $(this).attr("src", "sun.png")
});
